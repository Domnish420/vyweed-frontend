/**
 * VYWEED Strain Browser
 * React Native / Expo — drop into your Expo project
 *
 * Connects to: GET /api/v1/search
 *              GET /api/v1/search/suggest
 *              GET /api/v1/search/strain/:id
 *              GET /api/v1/search/stats
 *              GET /api/v1/search/filters
 *
 * Usage: import VYWEEDStrainBrowser from './VYWEEDStrainBrowser'
 *        Add to your navigator or render directly as a screen
 *
 * Optional prop: onSelectStrain(strain) — called when user taps "Start Grow"
 *                so you can navigate to the grow tracker with that strain pre-filled
 */

import React, {
  useState, useEffect, useCallback, useRef, useMemo,
} from "react";
import {
  View, Text, ScrollView, FlatList, TouchableOpacity, TextInput,
  Modal, ActivityIndicator, Animated, Dimensions,
  Platform, StatusBar, Alert,
} from "react-native";

const { width: SW, height: SH } = Dimensions.get("window");

// ── Config ────────────────────────────────────────────────────────────────────
const API_BASE = "http://localhost:8000/api/v1";

// ── Palette — same as grow tracker for cohesion ───────────────────────────────
const C = {
  bg:         "#070a07",
  surface:    "#0d120d",
  card:       "#111811",
  border:     "#1a2a1a",
  green:      "#39ff45",
  greenDim:   "#1a7a20",
  greenFaint: "#0d3d12",
  amber:      "#ffb830",
  red:        "#ff3a3a",
  blue:       "#30d5ff",
  purple:     "#c084fc",
  white:      "#e8f0e8",
  grey:       "#4a5a4a",
  greyLight:  "#8a9a8a",
};

const MONO = Platform.select({ ios: "Courier New", android: "monospace" });

// ── API ───────────────────────────────────────────────────────────────────────
const api = {
  async get(path) {
    const r = await fetch(`${API_BASE}${path}`);
    if (!r.ok) throw new Error(`${r.status}`);
    return r.json();
  },
};

// ── Helpers ───────────────────────────────────────────────────────────────────
const TYPE_COLOUR = { indica: C.purple, sativa: C.green, hybrid: C.amber };
const TYPE_ICON   = { indica: "◆", sativa: "▲", hybrid: "◈" };
const DIFF_COLOUR = { beginner: C.green, intermediate: C.amber, advanced: C.red };
const DIFF_ICON   = { beginner: "●", intermediate: "●●", advanced: "●●●" };
const EFFECT_ICON = { uplifting: "⬆", balanced: "⟺", sedating: "⬇" };
const EFFECT_COLOUR = { uplifting: C.green, balanced: C.amber, sedating: C.purple };

const TIER_DESC = {
  T1: "Pure landrace", T2: "Foundational classic",
  T3: "Modern staple", T4: "New wave / Auto",
};

function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }

// ── Shared components ─────────────────────────────────────────────────────────
function Label({ children, style }) {
  return (
    <Text style={[{
      color: C.greyLight, fontFamily: MONO, fontSize: 10,
      letterSpacing: 1.5, textTransform: "uppercase",
    }, style]}>
      {children}
    </Text>
  );
}

function Tag({ label, colour, onPress }) {
  return (
    <TouchableOpacity
      onPress={onPress} disabled={!onPress} activeOpacity={onPress ? 0.7 : 1}
      style={{
        backgroundColor: `${colour || C.green}22`,
        borderWidth: 1, borderColor: colour || C.green,
        borderRadius: 4, paddingHorizontal: 7, paddingVertical: 3,
      }}
    >
      <Text style={{ color: colour || C.green, fontFamily: MONO, fontSize: 10, fontWeight: "bold" }}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

function THCBar({ min, max }) {
  const pct = clamp(((max - 0) / 35) * 100, 0, 100);
  const col = max >= 25 ? C.red : max >= 20 ? C.amber : C.green;
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 8, flex: 1 }}>
      <View style={{ flex: 1, height: 4, backgroundColor: C.border, borderRadius: 2, overflow: "hidden" }}>
        <View style={{ width: `${pct}%`, height: 4, backgroundColor: col, borderRadius: 2 }} />
      </View>
      <Text style={{ color: col, fontFamily: MONO, fontSize: 11, fontWeight: "bold", width: 52 }}>
        {min}–{max}%
      </Text>
    </View>
  );
}

// ── COMPONENT: Strain Card ────────────────────────────────────────────────────
function StrainCard({ strain, onPress }) {
  const typeCol  = TYPE_COLOUR[strain.type]  || C.amber;
  const diffCol  = DIFF_COLOUR[strain.difficulty] || C.amber;
  const effectCol = EFFECT_COLOUR[strain.effect] || C.amber;

  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.8}>
      <View style={{
        backgroundColor: C.card, borderRadius: 8,
        borderWidth: 1, borderColor: C.border,
        borderLeftWidth: 3, borderLeftColor: typeCol,
        padding: 12, marginBottom: 8,
      }}>
        {/* Row 1: name + tier + type */}
        <View style={{ flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" }}>
          <View style={{ flex: 1, marginRight: 8 }}>
            <Text style={{ color: C.white, fontFamily: MONO, fontSize: 15, fontWeight: "bold" }}>
              {strain.name}
            </Text>
            <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10, marginTop: 2 }}>
              {strain.lineage?.slice(0, 48)}{strain.lineage?.length > 48 ? "…" : ""}
            </Text>
          </View>
          <View style={{ alignItems: "flex-end", gap: 4 }}>
            <View style={{ flexDirection: "row", gap: 4 }}>
              <Tag label={strain.tier} colour={C.greyLight} />
              <Tag label={`${TYPE_ICON[strain.type]} ${strain.type}`} colour={typeCol} />
            </View>
          </View>
        </View>

        {/* Row 2: THC bar */}
        <View style={{ flexDirection: "row", alignItems: "center", marginTop: 10, gap: 6 }}>
          <Label>THC</Label>
          <THCBar min={strain.thc_min} max={strain.thc_max} />
        </View>

        {/* Row 3: meta tags */}
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 8 }}>
          <Tag
            label={`${EFFECT_ICON[strain.effect] || ""} ${strain.effect}`}
            colour={effectCol}
          />
          <Tag
            label={`${DIFF_ICON[strain.difficulty] || "●"} ${strain.difficulty}`}
            colour={diffCol}
          />
          <Tag label={`🌸 ${strain.flower_wk_min}–${strain.flower_wk_max}wk`} colour={C.blue} />
          <Tag label={`📦 ${strain.yield_max_gm2}g/m²`} colour={C.greyLight} />
        </View>

        {/* Row 4: terpenes */}
        {strain.terpenes?.length > 0 && (
          <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10, marginTop: 6 }}>
            🧪 {strain.terpenes.slice(0, 3).join(" · ")}
          </Text>
        )}
      </View>
    </TouchableOpacity>
  );
}

// ── COMPONENT: Filter Sheet ───────────────────────────────────────────────────
function FilterSheet({ visible, filters, active, onApply, onClose }) {
  const [local, setLocal] = useState({ ...active });

  useEffect(() => { if (visible) setLocal({ ...active }); }, [visible]);

  const toggle = (key, val) => {
    setLocal(prev => ({
      ...prev,
      [key]: prev[key] === val ? null : val,
    }));
  };

  const clear = () => setLocal({
    tier: null, type: null, effect: null,
    difficulty: null, terpene: null,
    thc_min: null, thc_max: null, auto_only: false, sort: "name",
  });

  const BtnRow = ({ label, options, field, colours = {} }) => (
    <View style={{ marginBottom: 16 }}>
      <Label style={{ marginBottom: 8 }}>{label}</Label>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
        {options.map(opt => {
          const active = local[field] === opt;
          const col = colours[opt] || C.green;
          return (
            <TouchableOpacity key={opt} onPress={() => toggle(field, opt)}
              style={{
                paddingHorizontal: 12, paddingVertical: 7,
                borderRadius: 6, borderWidth: 1,
                borderColor: active ? col : C.border,
                backgroundColor: active ? `${col}22` : C.surface,
              }}
            >
              <Text style={{ color: active ? col : C.greyLight, fontFamily: MONO, fontSize: 12 }}>
                {opt}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );

  const SortRow = () => (
    <View style={{ marginBottom: 16 }}>
      <Label style={{ marginBottom: 8 }}>SORT BY</Label>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
        {["name","thc","yield","flower_wk","difficulty"].map(s => (
          <TouchableOpacity key={s} onPress={() => setLocal(p => ({ ...p, sort: s }))}
            style={{
              paddingHorizontal: 12, paddingVertical: 7,
              borderRadius: 6, borderWidth: 1,
              borderColor: local.sort === s ? C.green : C.border,
              backgroundColor: local.sort === s ? C.greenFaint : C.surface,
            }}
          >
            <Text style={{
              color: local.sort === s ? C.green : C.greyLight,
              fontFamily: MONO, fontSize: 12,
            }}>
              {s.replace("_"," ").toUpperCase()}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  const Toggle = ({ label, field }) => (
    <TouchableOpacity
      onPress={() => setLocal(p => ({ ...p, [field]: !p[field] }))}
      style={{
        flexDirection: "row", alignItems: "center", justifyContent: "space-between",
        paddingVertical: 10, borderBottomWidth: 1, borderColor: C.border, marginBottom: 10,
      }}
    >
      <Label>{label}</Label>
      <View style={{
        width: 44, height: 24, borderRadius: 12,
        backgroundColor: local[field] ? C.greenFaint : C.surface,
        borderWidth: 1, borderColor: local[field] ? C.green : C.border,
        justifyContent: "center", paddingHorizontal: 3,
      }}>
        <View style={{
          width: 18, height: 18, borderRadius: 9,
          backgroundColor: local[field] ? C.green : C.grey,
          alignSelf: local[field] ? "flex-end" : "flex-start",
        }} />
      </View>
    </TouchableOpacity>
  );

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.7)", justifyContent: "flex-end" }}>
        <View style={{
          backgroundColor: C.card, borderTopLeftRadius: 20, borderTopRightRadius: 20,
          borderTopWidth: 1, borderColor: C.border,
          maxHeight: SH * 0.85,
        }}>
          {/* Handle */}
          <View style={{ alignItems: "center", paddingTop: 12, paddingBottom: 4 }}>
            <View style={{ width: 40, height: 4, backgroundColor: C.border, borderRadius: 2 }} />
          </View>

          <View style={{
            flexDirection: "row", justifyContent: "space-between",
            alignItems: "center", paddingHorizontal: 16, paddingBottom: 12,
            borderBottomWidth: 1, borderColor: C.border,
          }}>
            <Text style={{ color: C.white, fontFamily: MONO, fontSize: 14, fontWeight: "bold" }}>
              FILTERS
            </Text>
            <TouchableOpacity onPress={clear}>
              <Text style={{ color: C.amber, fontFamily: MONO, fontSize: 12 }}>CLEAR ALL</Text>
            </TouchableOpacity>
          </View>

          <ScrollView contentContainerStyle={{ padding: 16 }}>
            <BtnRow label="TIER" field="tier"
              options={["T1","T2","T3","T4"]}
              colours={{ T1: C.amber, T2: C.purple, T3: C.blue, T4: C.green }} />

            <BtnRow label="TYPE" field="type"
              options={["indica","sativa","hybrid"]}
              colours={TYPE_COLOUR} />

            <BtnRow label="EFFECT" field="effect"
              options={["uplifting","balanced","sedating"]}
              colours={EFFECT_COLOUR} />

            <BtnRow label="DIFFICULTY" field="difficulty"
              options={["beginner","intermediate","advanced"]}
              colours={DIFF_COLOUR} />

            <Toggle label="AUTOFLOWERS ONLY" field="auto_only" />

            <SortRow />

            {/* THC range */}
            <View style={{ marginBottom: 16 }}>
              <Label style={{ marginBottom: 8 }}>THC RANGE</Label>
              <View style={{ flexDirection: "row", gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <Label style={{ marginBottom: 4 }}>MIN %</Label>
                  <TextInput
                    style={{
                      backgroundColor: C.surface, borderRadius: 6,
                      borderWidth: 1, borderColor: C.border,
                      color: C.white, fontFamily: MONO,
                      fontSize: 14, padding: 10,
                    }}
                    value={local.thc_min?.toString() || ""}
                    onChangeText={v => setLocal(p => ({ ...p, thc_min: v ? parseInt(v) : null }))}
                    keyboardType="number-pad"
                    placeholder="0" placeholderTextColor={C.grey}
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Label style={{ marginBottom: 4 }}>MAX %</Label>
                  <TextInput
                    style={{
                      backgroundColor: C.surface, borderRadius: 6,
                      borderWidth: 1, borderColor: C.border,
                      color: C.white, fontFamily: MONO,
                      fontSize: 14, padding: 10,
                    }}
                    value={local.thc_max?.toString() || ""}
                    onChangeText={v => setLocal(p => ({ ...p, thc_max: v ? parseInt(v) : null }))}
                    keyboardType="number-pad"
                    placeholder="35" placeholderTextColor={C.grey}
                  />
                </View>
              </View>
            </View>

            {/* Popular terpenes */}
            <BtnRow label="TERPENE" field="terpene"
              options={["Myrcene","Limonene","Beta-Caryophyllene","Terpinolene","Linalool","Pinene","Ocimene"]}
              colours={{ Myrcene: C.green, Limonene: C.amber, "Beta-Caryophyllene": C.red,
                Terpinolene: C.blue, Linalool: C.purple, Pinene: C.green, Ocimene: C.amber }} />
          </ScrollView>

          <View style={{ padding: 16, flexDirection: "row", gap: 10 }}>
            <TouchableOpacity onPress={onClose}
              style={{
                flex: 1, borderWidth: 1, borderColor: C.border,
                borderRadius: 6, padding: 12, alignItems: "center",
              }}>
              <Text style={{ color: C.greyLight, fontFamily: MONO, fontSize: 13 }}>CANCEL</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => { onApply(local); onClose(); }}
              style={{
                flex: 2, backgroundColor: C.greenFaint,
                borderWidth: 1, borderColor: C.green,
                borderRadius: 6, padding: 12, alignItems: "center",
              }}>
              <Text style={{ color: C.green, fontFamily: MONO,
                fontSize: 13, fontWeight: "bold" }}>
                APPLY FILTERS
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

// ── SCREEN: Strain Detail ─────────────────────────────────────────────────────
function StrainDetailScreen({ strainId, onBack, onStartGrow }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/search/strain/${strainId}`)
      .then(setData)
      .catch(e => Alert.alert("Error", e.message))
      .finally(() => setLoading(false));
  }, [strainId]);

  if (loading || !data) {
    return (
      <View style={{ flex: 1, backgroundColor: C.bg, alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color={C.green} />
      </View>
    );
  }

  const typeCol   = TYPE_COLOUR[data.type]      || C.amber;
  const diffCol   = DIFF_COLOUR[data.difficulty] || C.amber;
  const effectCol = EFFECT_COLOUR[data.effect]   || C.amber;

  const InfoRow = ({ label, value, colour }) => (
    <View style={{
      flexDirection: "row", justifyContent: "space-between",
      alignItems: "center", paddingVertical: 10,
      borderBottomWidth: 1, borderColor: C.border,
    }}>
      <Label>{label}</Label>
      <Text style={{ color: colour || C.white, fontFamily: MONO, fontSize: 13, fontWeight: "bold" }}>
        {value}
      </Text>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      {/* Header */}
      <View style={{
        paddingHorizontal: 16,
        paddingTop: Platform.OS === "android" ? 16 : 52,
        paddingBottom: 12,
        borderBottomWidth: 1, borderColor: C.border,
        backgroundColor: C.card,
      }}>
        <TouchableOpacity onPress={onBack} style={{ marginBottom: 8 }}>
          <Text style={{ color: C.green, fontFamily: MONO, fontSize: 14 }}>← BACK</Text>
        </TouchableOpacity>
        <Text style={{ color: C.white, fontFamily: MONO, fontSize: 22, fontWeight: "bold" }}>
          {data.name}
        </Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 8 }}>
          <Tag label={data.tier} colour={C.greyLight} />
          <Tag label={`${TYPE_ICON[data.type]} ${data.type}`} colour={typeCol} />
          <Tag label={`${EFFECT_ICON[data.effect] || ""} ${data.effect}`} colour={effectCol} />
          <Tag label={`${DIFF_ICON[data.difficulty] || "●"} ${data.difficulty}`} colour={diffCol} />
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 50 }}>

        {/* THC / CBD Hero */}
        <View style={{
          backgroundColor: C.card, borderRadius: 8,
          borderWidth: 1, borderColor: C.border,
          padding: 16, marginBottom: 12,
        }}>
          <View style={{ flexDirection: "row", gap: 12, marginBottom: 12 }}>
            <View style={{ flex: 1, alignItems: "center" }}>
              <Label>THC</Label>
              <Text style={{
                color: data.thc_max >= 25 ? C.red : data.thc_max >= 20 ? C.amber : C.green,
                fontFamily: MONO, fontSize: 28, fontWeight: "bold", marginTop: 4,
              }}>
                {data.thc_max}%
              </Text>
              <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10 }}>
                range {data.thc_min}–{data.thc_max}%
              </Text>
            </View>
            <View style={{ width: 1, backgroundColor: C.border }} />
            <View style={{ flex: 1, alignItems: "center" }}>
              <Label>CBD</Label>
              <Text style={{ color: C.blue, fontFamily: MONO, fontSize: 28,
                fontWeight: "bold", marginTop: 4 }}>
                {data.cbd_max >= 5 ? `${data.cbd_max}%` : "LOW"}
              </Text>
              <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10 }}>
                max {data.cbd_max}%
              </Text>
            </View>
            <View style={{ width: 1, backgroundColor: C.border }} />
            <View style={{ flex: 1, alignItems: "center" }}>
              <Label>INDICA/SATIVA</Label>
              <Text style={{ color: typeCol, fontFamily: MONO, fontSize: 16,
                fontWeight: "bold", marginTop: 4 }}>
                {data.indica_pct}/{data.sativa_pct}
              </Text>
              {/* Mini split bar */}
              <View style={{ flexDirection: "row", height: 6, width: "100%",
                marginTop: 6, borderRadius: 3, overflow: "hidden" }}>
                <View style={{ flex: data.indica_pct, backgroundColor: C.purple }} />
                <View style={{ flex: data.sativa_pct, backgroundColor: C.green }} />
              </View>
            </View>
          </View>
        </View>

        {/* Grow stats */}
        <View style={{
          backgroundColor: C.card, borderRadius: 8,
          borderWidth: 1, borderColor: C.border,
          padding: 16, marginBottom: 12,
        }}>
          <Label style={{ marginBottom: 8 }}>GROW STATS</Label>
          <InfoRow label="FLOWER TIME"
            value={`${data.flower_wk_min}–${data.flower_wk_max} weeks`}
            colour={C.blue} />
          <InfoRow label="INDOOR YIELD"
            value={`${data.yield_min_gm2}–${data.yield_max_gm2} g/m²`}
            colour={C.amber} />
          <InfoRow label="HEIGHT"
            value={`${data.height_min_cm}–${data.height_max_cm} cm`}
            colour={C.greyLight} />
          <InfoRow label="DIFFICULTY"
            value={data.difficulty.toUpperCase()}
            colour={diffCol} />
        </View>

        {/* Aroma */}
        {data.aroma && (
          <View style={{
            backgroundColor: C.card, borderRadius: 8,
            borderWidth: 1, borderColor: C.border,
            padding: 16, marginBottom: 12,
          }}>
            <Label style={{ marginBottom: 8 }}>AROMA & FLAVOUR</Label>
            <Text style={{ color: C.white, fontFamily: MONO, fontSize: 14, lineHeight: 20 }}>
              🌿 {data.aroma}
            </Text>
          </View>
        )}

        {/* Terpenes */}
        {data.terpenes?.length > 0 && (
          <View style={{
            backgroundColor: C.card, borderRadius: 8,
            borderWidth: 1, borderColor: C.border,
            padding: 16, marginBottom: 12,
          }}>
            <Label style={{ marginBottom: 10 }}>TERPENES</Label>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {data.terpenes.map((t, i) => (
                <View key={i} style={{
                  backgroundColor: C.surface, borderRadius: 6,
                  borderWidth: 1, borderColor: C.border,
                  paddingHorizontal: 10, paddingVertical: 6,
                }}>
                  <Text style={{ color: C.green, fontFamily: MONO, fontSize: 12 }}>🧪 {t}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Lineage / Origin */}
        <View style={{
          backgroundColor: C.card, borderRadius: 8,
          borderWidth: 1, borderColor: C.border,
          padding: 16, marginBottom: 12,
        }}>
          <Label style={{ marginBottom: 8 }}>GENETICS</Label>
          <Text style={{ color: C.amber, fontFamily: MONO, fontSize: 13,
            lineHeight: 19, marginBottom: 8 }}>
            🧬 {data.lineage}
          </Text>
          <Label style={{ marginBottom: 4 }}>ORIGIN</Label>
          <Text style={{ color: C.greyLight, fontFamily: MONO, fontSize: 12, lineHeight: 18 }}>
            📍 {data.origin}
          </Text>
        </View>

        {/* Start Grow CTA */}
        {onStartGrow && (
          <TouchableOpacity
            onPress={() => onStartGrow(data)}
            activeOpacity={0.8}
            style={{
              backgroundColor: C.greenFaint, borderRadius: 8,
              borderWidth: 1, borderColor: C.green,
              padding: 16, alignItems: "center", marginBottom: 8,
            }}
          >
            <Text style={{ color: C.green, fontFamily: MONO,
              fontSize: 15, fontWeight: "bold", letterSpacing: 1 }}>
              🌱 START GROW WITH THIS STRAIN
            </Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
}

// ── SCREEN: Recommender ───────────────────────────────────────────────────────
function RecommendScreen({ onBack, onSelectStrain }) {
  const [prefs, setPrefs] = useState({
    experience: "beginner",
    effect: "balanced",
    space_cm: "100",
    want_auto: false,
    thc_preference: "medium",
  });
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);

  const run = async () => {
    setLoading(true);
    try {
      const q = new URLSearchParams({
        experience: prefs.experience,
        effect: prefs.effect,
        space_cm: prefs.space_cm || 100,
        want_auto: prefs.want_auto,
        thc_preference: prefs.thc_preference,
        limit: 6,
      }).toString();
      const data = await api.get(`/search/recommend?${q}`);
      setResults(data);
    } catch (e) {
      Alert.alert("Error", e.message);
    } finally {
      setLoading(false);
    }
  };

  const BtnRow = ({ label, field, options, colours = {} }) => (
    <View style={{ marginBottom: 16 }}>
      <Label style={{ marginBottom: 8 }}>{label}</Label>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
        {options.map(opt => {
          const active = prefs[field] === opt;
          const col = colours[opt] || C.green;
          return (
            <TouchableOpacity key={opt}
              onPress={() => setPrefs(p => ({ ...p, [field]: opt }))}
              style={{
                paddingHorizontal: 14, paddingVertical: 9,
                borderRadius: 8, borderWidth: 1,
                borderColor: active ? col : C.border,
                backgroundColor: active ? `${col}22` : C.surface,
              }}
            >
              <Text style={{ color: active ? col : C.greyLight,
                fontFamily: MONO, fontSize: 12 }}>
                {opt}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <View style={{
        flexDirection: "row", alignItems: "center",
        paddingHorizontal: 16,
        paddingTop: Platform.OS === "android" ? 16 : 52,
        paddingBottom: 12,
        borderBottomWidth: 1, borderColor: C.border,
      }}>
        <TouchableOpacity onPress={onBack} style={{ marginRight: 12 }}>
          <Text style={{ color: C.green, fontFamily: MONO, fontSize: 18 }}>←</Text>
        </TouchableOpacity>
        <Text style={{ color: C.white, fontFamily: MONO, fontSize: 16, fontWeight: "bold" }}>
          STRAIN RECOMMENDER
        </Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
        <BtnRow label="YOUR EXPERIENCE" field="experience"
          options={["beginner","intermediate","advanced"]}
          colours={DIFF_COLOUR} />

        <BtnRow label="DESIRED EFFECT" field="effect"
          options={["uplifting","balanced","sedating"]}
          colours={EFFECT_COLOUR} />

        <BtnRow label="THC STRENGTH" field="thc_preference"
          options={["low","medium","high"]}
          colours={{ low: C.green, medium: C.amber, high: C.red }} />

        <View style={{ marginBottom: 16 }}>
          <Label style={{ marginBottom: 8 }}>MAX PLANT HEIGHT (CM)</Label>
          <TextInput
            style={{
              backgroundColor: C.surface, borderRadius: 6,
              borderWidth: 1, borderColor: C.border,
              color: C.white, fontFamily: MONO, fontSize: 16,
              padding: 12,
            }}
            value={prefs.space_cm}
            onChangeText={v => setPrefs(p => ({ ...p, space_cm: v }))}
            keyboardType="number-pad"
            placeholder="100"
            placeholderTextColor={C.grey}
          />
        </View>

        {/* Auto toggle */}
        <TouchableOpacity
          onPress={() => setPrefs(p => ({ ...p, want_auto: !p.want_auto }))}
          style={{
            flexDirection: "row", alignItems: "center",
            justifyContent: "space-between",
            backgroundColor: C.card, borderRadius: 8,
            borderWidth: 1, borderColor: C.border,
            padding: 14, marginBottom: 20,
          }}
        >
          <View>
            <Text style={{ color: C.white, fontFamily: MONO, fontSize: 13 }}>
              PREFER AUTOFLOWERS
            </Text>
            <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10, marginTop: 2 }}>
              No light schedule needed — easier for beginners
            </Text>
          </View>
          <View style={{
            width: 44, height: 24, borderRadius: 12,
            backgroundColor: prefs.want_auto ? C.greenFaint : C.surface,
            borderWidth: 1, borderColor: prefs.want_auto ? C.green : C.border,
            justifyContent: "center", paddingHorizontal: 3,
          }}>
            <View style={{
              width: 18, height: 18, borderRadius: 9,
              backgroundColor: prefs.want_auto ? C.green : C.grey,
              alignSelf: prefs.want_auto ? "flex-end" : "flex-start",
            }} />
          </View>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={run} activeOpacity={0.8}
          style={{
            backgroundColor: C.greenFaint, borderRadius: 8,
            borderWidth: 1, borderColor: C.green,
            padding: 14, alignItems: "center", marginBottom: 24,
          }}
        >
          {loading
            ? <ActivityIndicator color={C.green} />
            : <Text style={{ color: C.green, fontFamily: MONO,
                fontSize: 14, fontWeight: "bold", letterSpacing: 1 }}>
                FIND MY STRAIN →
              </Text>
          }
        </TouchableOpacity>

        {/* Results */}
        {results && (
          <>
            <Label style={{ marginBottom: 10 }}>
              TOP {results.count} MATCHES
            </Label>
            {results.recommendations.map((s, i) => (
              <TouchableOpacity key={s.id} onPress={() => onSelectStrain?.(s)} activeOpacity={0.8}>
                <View style={{
                  backgroundColor: C.card, borderRadius: 8,
                  borderWidth: 1, borderColor: i === 0 ? C.green : C.border,
                  borderLeftWidth: i === 0 ? 3 : 1,
                  borderLeftColor: i === 0 ? C.green : C.border,
                  padding: 14, marginBottom: 8,
                  flexDirection: "row", alignItems: "center", gap: 12,
                }}>
                  <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 20, fontWeight: "bold" }}>
                    #{i + 1}
                  </Text>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: i === 0 ? C.green : C.white,
                      fontFamily: MONO, fontSize: 14, fontWeight: "bold" }}>
                      {s.name}
                    </Text>
                    <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 11, marginTop: 2 }}>
                      THC {s.thc_max}% · {s.flower_wk_max}wk · {s.height_max_cm}cm
                    </Text>
                  </View>
                  <View style={{ alignItems: "flex-end", gap: 4 }}>
                    <Tag label={s.type} colour={TYPE_COLOUR[s.type]} />
                    <Tag label={s.difficulty} colour={DIFF_COLOUR[s.difficulty]} />
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </>
        )}
      </ScrollView>
    </View>
  );
}

// ── SCREEN: DB Stats ──────────────────────────────────────────────────────────
function StatsCard({ stats }) {
  if (!stats) return null;
  const rows = [
    ["TOTAL STRAINS", stats.total, C.green],
    ["AUTOFLOWERS",   stats.autoflowers, C.blue],
    ["PHOTOPERIOD",   stats.photoperiod, C.amber],
    ["BEGINNERS",     stats.by_difficulty?.beginner, C.green],
    ["ADVANCED",      stats.by_difficulty?.advanced, C.red],
  ];
  return (
    <View style={{
      backgroundColor: C.card, borderRadius: 8,
      borderWidth: 1, borderColor: C.border,
      padding: 14, marginBottom: 12,
    }}>
      <Label style={{ marginBottom: 10 }}>DATABASE</Label>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 6 }}>
        {rows.map(([label, val, col]) => (
          <View key={label} style={{
            backgroundColor: C.surface, borderRadius: 6, borderWidth: 1,
            borderColor: C.border, padding: 10, minWidth: (SW - 68) / 3,
            alignItems: "center",
          }}>
            <Text style={{ color: col, fontFamily: MONO, fontSize: 20, fontWeight: "bold" }}>
              {val?.toLocaleString() ?? "—"}
            </Text>
            <Label style={{ marginTop: 2, fontSize: 9 }}>{label}</Label>
          </View>
        ))}
      </View>
    </View>
  );
}

// ── MAIN: Strain Browser ──────────────────────────────────────────────────────
export default function VYWEEDStrainBrowser({ onSelectStrain }) {
  const [screen, setScreen] = useState("browse"); // browse | detail | recommend
  const [detailId, setDetailId] = useState(null);

  // Search state
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filters, setFilters] = useState({
    tier: null, type: null, effect: null, difficulty: null,
    terpene: null, thc_min: null, thc_max: null,
    auto_only: false, sort: "name",
  });
  const [showFilters, setShowFilters] = useState(false);

  // Results state
  const [results, setResults] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [stats, setStats] = useState(null);

  const PER_PAGE = 20;
  const activeFilterCount = Object.values(filters).filter(
    v => v !== null && v !== false && v !== "name"
  ).length;

  // Load stats once
  useEffect(() => {
    api.get("/search/stats").then(setStats).catch(() => {});
  }, []);

  // Build query string
  const buildQS = useCallback((p = 1) => {
    const params = new URLSearchParams({ page: p, per_page: PER_PAGE, sort: filters.sort });
    if (query.trim()) params.set("q", query.trim());
    if (filters.tier)       params.set("tier", filters.tier);
    if (filters.type)       params.set("type", filters.type);
    if (filters.effect)     params.set("effect", filters.effect);
    if (filters.difficulty) params.set("difficulty", filters.difficulty);
    if (filters.terpene)    params.set("terpene", filters.terpene);
    if (filters.thc_min != null) params.set("thc_min", filters.thc_min);
    if (filters.thc_max != null) params.set("thc_max", filters.thc_max);
    if (filters.auto_only)  params.set("auto_only", true);
    return params.toString();
  }, [query, filters]);

  // Search
  const search = useCallback(async (reset = true) => {
    if (reset) {
      setLoading(true);
      setPage(1);
    } else {
      setLoadingMore(true);
    }
    try {
      const p = reset ? 1 : page + 1;
      const data = await api.get(`/search?${buildQS(p)}`);
      if (reset) {
        setResults(data.results);
      } else {
        setResults(prev => [...prev, ...data.results]);
        setPage(p);
      }
      setTotal(data.total);
    } catch (e) {
      Alert.alert("Search error", e.message);
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, [buildQS, page]);

  // Trigger search when query or filters change
  useEffect(() => { search(true); }, [query, filters]);

  // Autocomplete
  const fetchSuggestions = useCallback(async (q) => {
    if (q.length < 2) { setSuggestions([]); return; }
    try {
      const data = await api.get(`/search/suggest?q=${encodeURIComponent(q)}&limit=8`);
      setSuggestions(data.suggestions || []);
      setShowSuggestions(true);
    } catch { setSuggestions([]); }
  }, []);

  const pickSuggestion = (s) => {
    setQuery(s.name);
    setSuggestions([]);
    setShowSuggestions(false);
  };

  // Sub-screens
  if (screen === "detail") {
    return (
      <StrainDetailScreen
        strainId={detailId}
        onBack={() => setScreen("browse")}
        onStartGrow={onSelectStrain ? (s) => { onSelectStrain(s); setScreen("browse"); } : null}
      />
    );
  }

  if (screen === "recommend") {
    return (
      <RecommendScreen
        onBack={() => setScreen("browse")}
        onSelectStrain={(s) => {
          setDetailId(s.id);
          setScreen("detail");
        }}
      />
    );
  }

  // ── Browse screen ─────────────────────────────────────────────────────────
  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />

      {/* Header */}
      <View style={{
        paddingHorizontal: 16,
        paddingTop: Platform.OS === "android" ? 16 : 52,
        paddingBottom: 10,
        borderBottomWidth: 1, borderColor: C.border,
      }}>
        <View style={{ flexDirection: "row", alignItems: "center",
          justifyContent: "space-between", marginBottom: 10 }}>
          <View>
            <Text style={{ color: C.white, fontFamily: MONO,
              fontSize: 22, fontWeight: "900", letterSpacing: 2 }}>
              VY<Text style={{ color: C.green }}>WEED</Text>
            </Text>
            <Label>STRAIN BROWSER</Label>
          </View>
          <TouchableOpacity onPress={() => setScreen("recommend")}
            style={{
              backgroundColor: C.greenFaint, borderRadius: 6,
              borderWidth: 1, borderColor: C.green,
              paddingHorizontal: 12, paddingVertical: 8,
            }}>
            <Text style={{ color: C.green, fontFamily: MONO, fontSize: 11, fontWeight: "bold" }}>
              🎯 FIND MINE
            </Text>
          </TouchableOpacity>
        </View>

        {/* Search bar */}
        <View style={{ flexDirection: "row", gap: 8 }}>
          <View style={{ flex: 1, position: "relative" }}>
            <View style={{
              flexDirection: "row", alignItems: "center",
              backgroundColor: C.surface, borderRadius: 8,
              borderWidth: 1, borderColor: query ? C.green : C.border,
              paddingHorizontal: 12,
            }}>
              <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 14, marginRight: 8 }}>⌕</Text>
              <TextInput
                style={{ flex: 1, color: C.white, fontFamily: MONO, fontSize: 14,
                  paddingVertical: 11 }}
                value={query}
                onChangeText={(t) => { setQuery(t); fetchSuggestions(t); }}
                onFocus={() => query.length >= 2 && setShowSuggestions(true)}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
                placeholder="Search 5,042 strains..."
                placeholderTextColor={C.grey}
                returnKeyType="search"
              />
              {query.length > 0 && (
                <TouchableOpacity onPress={() => { setQuery(""); setSuggestions([]); }}>
                  <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 16 }}>✕</Text>
                </TouchableOpacity>
              )}
            </View>

            {/* Autocomplete dropdown */}
            {showSuggestions && suggestions.length > 0 && (
              <View style={{
                position: "absolute", top: 46, left: 0, right: 0, zIndex: 100,
                backgroundColor: C.card, borderRadius: 8,
                borderWidth: 1, borderColor: C.border,
                shadowColor: "#000", shadowOpacity: 0.5, shadowRadius: 8,
                elevation: 8,
              }}>
                {suggestions.map(s => (
                  <TouchableOpacity key={s.id} onPress={() => pickSuggestion(s)}
                    style={{ padding: 12, borderBottomWidth: 1, borderColor: C.border }}>
                    <Text style={{ color: C.white, fontFamily: MONO, fontSize: 13 }}>
                      {s.name}
                    </Text>
                    <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10, marginTop: 2 }}>
                      {s.tier} · {s.type} · {s.thc_max}% THC
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          {/* Filter button */}
          <TouchableOpacity
            onPress={() => setShowFilters(true)}
            style={{
              backgroundColor: activeFilterCount > 0 ? C.greenFaint : C.surface,
              borderRadius: 8, borderWidth: 1,
              borderColor: activeFilterCount > 0 ? C.green : C.border,
              paddingHorizontal: 12, alignItems: "center", justifyContent: "center",
              minWidth: 50,
            }}
          >
            <Text style={{ color: activeFilterCount > 0 ? C.green : C.greyLight,
              fontFamily: MONO, fontSize: 16 }}>⚙</Text>
            {activeFilterCount > 0 && (
              <View style={{
                position: "absolute", top: -4, right: -4,
                backgroundColor: C.green, borderRadius: 8,
                width: 16, height: 16, alignItems: "center", justifyContent: "center",
              }}>
                <Text style={{ color: C.bg, fontFamily: MONO,
                  fontSize: 9, fontWeight: "bold" }}>
                  {activeFilterCount}
                </Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Results count + active filter chips */}
        <View style={{ flexDirection: "row", alignItems: "center",
          marginTop: 8, flexWrap: "wrap", gap: 6 }}>
          <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 11 }}>
            {loading ? "SEARCHING..." : `${total.toLocaleString()} STRAINS`}
          </Text>
          {filters.type && <Tag label={filters.type} colour={TYPE_COLOUR[filters.type]}
            onPress={() => setFilters(p => ({ ...p, type: null }))} />}
          {filters.tier && <Tag label={filters.tier} colour={C.greyLight}
            onPress={() => setFilters(p => ({ ...p, tier: null }))} />}
          {filters.effect && <Tag label={filters.effect} colour={EFFECT_COLOUR[filters.effect]}
            onPress={() => setFilters(p => ({ ...p, effect: null }))} />}
          {filters.difficulty && <Tag label={filters.difficulty} colour={DIFF_COLOUR[filters.difficulty]}
            onPress={() => setFilters(p => ({ ...p, difficulty: null }))} />}
          {filters.auto_only && <Tag label="AUTO ONLY" colour={C.blue}
            onPress={() => setFilters(p => ({ ...p, auto_only: false }))} />}
        </View>
      </View>

      {/* List */}
      {loading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator color={C.green} size="large" />
          <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 12, marginTop: 12 }}>
            SEARCHING...
          </Text>
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={item => item.id}
          contentContainerStyle={{ padding: 12, paddingBottom: 40 }}
          ListHeaderComponent={!query && activeFilterCount === 0
            ? <StatsCard stats={stats} />
            : null}
          renderItem={({ item }) => (
            <StrainCard
              strain={item}
              onPress={() => { setDetailId(item.id); setScreen("detail"); }}
            />
          )}
          onEndReached={() => {
            if (!loadingMore && results.length < total) search(false);
          }}
          onEndReachedThreshold={0.3}
          ListFooterComponent={loadingMore
            ? <ActivityIndicator color={C.green} style={{ marginVertical: 20 }} />
            : results.length < total
              ? <Text style={{ color: C.grey, fontFamily: MONO,
                  fontSize: 11, textAlign: "center", marginVertical: 16 }}>
                  Scroll for more ({total - results.length} remaining)
                </Text>
              : null
          }
          ListEmptyComponent={
            <View style={{ alignItems: "center", paddingVertical: 60 }}>
              <Text style={{ fontSize: 36 }}>🔍</Text>
              <Text style={{ color: C.grey, fontFamily: MONO,
                fontSize: 14, marginTop: 12 }}>
                NO STRAINS FOUND
              </Text>
              <Text style={{ color: C.grey, fontFamily: MONO,
                fontSize: 11, marginTop: 6 }}>
                Try different search terms or clear filters
              </Text>
            </View>
          }
        />
      )}

      {/* Filter sheet */}
      <FilterSheet
        visible={showFilters}
        filters={null}
        active={filters}
        onApply={(f) => setFilters(f)}
        onClose={() => setShowFilters(false)}
      />
    </View>
  );
}
