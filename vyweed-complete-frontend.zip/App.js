/**
 * VYWEED — App.js
 * Tab navigator wiring Strain Browser + Grow Tracker + VPD Calc + Settings
 *
 * Setup in Termux:
 *   npx create-expo-app vyweed --template blank
 *   cd vyweed
 *   npm install @react-navigation/native @react-navigation/bottom-tabs
 *   npm install react-native-screens react-native-safe-area-context
 *   cp ~/storage/downloads/App.js .
 *   cp ~/storage/downloads/VYWEEDStrainBrowser.jsx .
 *   cp ~/storage/downloads/VYWEEDGrowTracker.jsx .
 *   npx expo start
 */

import React, { useState, useCallback } from "react";
import {
  View, Text, TouchableOpacity, Platform, StatusBar,
  Dimensions, Animated,
} from "react-native";
import { SafeAreaProvider, SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";

import VYWEEDStrainBrowser from "./VYWEEDStrainBrowser";
import VYWEEDGrowTracker   from "./VYWEEDGrowTracker";
import VPDCalculator        from "./VPDCalculator";    // built below
import SettingsScreen       from "./SettingsScreen";   // built below

const { width: SW } = Dimensions.get("window");

// ── Palette ───────────────────────────────────────────────────────────────────
const C = {
  bg:         "#070a07",
  surface:    "#0d120d",
  card:       "#111811",
  border:     "#1a2a1a",
  green:      "#39ff45",
  greenFaint: "#0d3d12",
  greenDim:   "#1a7a20",
  amber:      "#ffb830",
  blue:       "#30d5ff",
  grey:       "#4a5a4a",
  greyLight:  "#8a9a8a",
  white:      "#e8f0e8",
};

const MONO = Platform.select({ ios: "Courier New", android: "monospace" });

// ── Tab definitions ───────────────────────────────────────────────────────────
const TABS = [
  { id: "browse",  label: "STRAINS",  icon: "🌿" },
  { id: "grows",   label: "MY GROWS", icon: "📊" },
  { id: "vpd",     label: "VPD",      icon: "🌡" },
  { id: "settings",label: "SETTINGS", icon: "⚙" },
];

// ── Custom tab bar ────────────────────────────────────────────────────────────
function TabBar({ active, onPress, growCount }) {
  const insets = useSafeAreaInsets();

  return (
    <View style={{
      flexDirection: "row",
      backgroundColor: C.card,
      borderTopWidth: 1,
      borderColor: C.border,
      paddingBottom: insets.bottom || 8,
      paddingTop: 8,
    }}>
      {TABS.map(tab => {
        const isActive = active === tab.id;
        return (
          <TouchableOpacity
            key={tab.id}
            onPress={() => onPress(tab.id)}
            activeOpacity={0.7}
            style={{
              flex: 1, alignItems: "center", paddingVertical: 4,
              borderTopWidth: 2,
              borderColor: isActive ? C.green : "transparent",
            }}
          >
            {/* Icon with badge for grows */}
            <View style={{ position: "relative" }}>
              <Text style={{ fontSize: 20 }}>{tab.icon}</Text>
              {tab.id === "grows" && growCount > 0 && (
                <View style={{
                  position: "absolute", top: -4, right: -8,
                  backgroundColor: C.green, borderRadius: 8,
                  minWidth: 16, height: 16,
                  alignItems: "center", justifyContent: "center",
                  paddingHorizontal: 3,
                }}>
                  <Text style={{
                    color: C.bg, fontFamily: MONO,
                    fontSize: 9, fontWeight: "bold",
                  }}>
                    {growCount}
                  </Text>
                </View>
              )}
            </View>
            <Text style={{
              color: isActive ? C.green : C.grey,
              fontFamily: MONO,
              fontSize: 9,
              fontWeight: isActive ? "bold" : "normal",
              letterSpacing: 0.8,
              marginTop: 3,
            }}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

// ── Root app ──────────────────────────────────────────────────────────────────
export default function App() {
  const [activeTab, setActiveTab]   = useState("browse");
  const [growCount, setGrowCount]   = useState(0);

  // When user taps "Start Grow" in strain browser — switch to grows tab
  const handleSelectStrain = useCallback((strain) => {
    // In a real app you'd pass strain data through to the tracker
    // For now just switch tabs — tracker has its own "New Grow" button
    setActiveTab("grows");
  }, []);

  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />

      {/* Screens — all mounted, only one visible at a time for instant switching */}
      <View style={{ flex: 1, backgroundColor: C.bg }}>

        {/* STRAIN BROWSER */}
        <View style={{ flex: 1, display: activeTab === "browse" ? "flex" : "none" }}>
          <VYWEEDStrainBrowser onSelectStrain={handleSelectStrain} />
        </View>

        {/* GROW TRACKER */}
        <View style={{ flex: 1, display: activeTab === "grows" ? "flex" : "none" }}>
          <VYWEEDGrowTracker onGrowCountChange={setGrowCount} />
        </View>

        {/* VPD CALCULATOR */}
        <View style={{ flex: 1, display: activeTab === "vpd" ? "flex" : "none" }}>
          <VPDCalculator />
        </View>

        {/* SETTINGS */}
        <View style={{ flex: 1, display: activeTab === "settings" ? "flex" : "none" }}>
          <SettingsScreen />
        </View>

      </View>

      {/* Tab bar always at bottom */}
      <TabBar
        active={activeTab}
        onPress={setActiveTab}
        growCount={growCount}
      />
    </SafeAreaProvider>
  );
}
