/**
 * SettingsScreen.jsx
 * App settings — API URL, units, about
 * Uses AsyncStorage for persistence (install: npx expo install @react-native-async-storage/async-storage)
 */

import React, { useState, useEffect } from "react";
import {
  View, Text, ScrollView, TextInput, TouchableOpacity,
  Switch, Alert, Platform, Linking,
} from "react-native";

// Try to import AsyncStorage — gracefully fail if not installed
let AsyncStorage = null;
try { AsyncStorage = require("@react-native-async-storage/async-storage").default; } catch {}

const C = {
  bg:         "#070a07",
  surface:    "#0d120d",
  card:       "#111811",
  border:     "#1a2a1a",
  green:      "#39ff45",
  greenFaint: "#0d3d12",
  greenDim:   "#1a7a20",
  amber:      "#ffb830",
  red:        "#ff3a3a",
  blue:       "#30d5ff",
  white:      "#e8f0e8",
  grey:       "#4a5a4a",
  greyLight:  "#8a9a8a",
};

const MONO = Platform.select({ ios: "Courier New", android: "monospace" });

const DEFAULTS = {
  api_url:   "http://localhost:8000/api/v1",
  units:     "metric",
  medium:    "soil",
  dark_mode: true,          // always true for now, just showing the toggle
};

function Label({ children, style }) {
  return (
    <Text style={[{
      color: C.greyLight, fontFamily: MONO, fontSize: 10,
      letterSpacing: 1.5, textTransform: "uppercase",
    }, style]}>
      {children}
    </Text>
  );
}

function Section({ title, children }) {
  return (
    <View style={{ marginBottom: 24 }}>
      <Label style={{ marginBottom: 10, marginLeft: 4 }}>{title}</Label>
      <View style={{
        backgroundColor: C.card, borderRadius: 10,
        borderWidth: 1, borderColor: C.border, overflow: "hidden",
      }}>
        {children}
      </View>
    </View>
  );
}

function SettingRow({ label, sub, right, onPress, last }) {
  const Wrap = onPress ? TouchableOpacity : View;
  return (
    <Wrap onPress={onPress} activeOpacity={0.7}
      style={{
        flexDirection: "row", alignItems: "center",
        paddingVertical: 14, paddingHorizontal: 14,
        borderBottomWidth: last ? 0 : 1, borderColor: C.border,
      }}
    >
      <View style={{ flex: 1 }}>
        <Text style={{ color: C.white, fontFamily: MONO, fontSize: 13 }}>{label}</Text>
        {sub && <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10, marginTop: 2 }}>{sub}</Text>}
      </View>
      {right}
    </Wrap>
  );
}

function SelectRow({ label, sub, options, value, onChange, last }) {
  return (
    <View style={{
      paddingVertical: 12, paddingHorizontal: 14,
      borderBottomWidth: last ? 0 : 1, borderColor: C.border,
    }}>
      <Text style={{ color: C.white, fontFamily: MONO, fontSize: 13, marginBottom: 8 }}>{label}</Text>
      {sub && <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10, marginBottom: 8 }}>{sub}</Text>}
      <View style={{ flexDirection: "row", gap: 8 }}>
        {options.map(opt => (
          <TouchableOpacity key={opt.value} onPress={() => onChange(opt.value)}
            style={{
              flex: 1, paddingVertical: 8, borderRadius: 6, alignItems: "center",
              borderWidth: 1,
              borderColor: value === opt.value ? C.green : C.border,
              backgroundColor: value === opt.value ? C.greenFaint : C.surface,
            }}>
            <Text style={{
              color: value === opt.value ? C.green : C.greyLight,
              fontFamily: MONO, fontSize: 12,
            }}>
              {opt.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

export default function SettingsScreen() {
  const [settings, setSettings] = useState({ ...DEFAULTS });
  const [apiTest, setApiTest]   = useState(null); // null | "ok" | "fail"
  const [testing, setTesting]   = useState(false);
  const [saved, setSaved]       = useState(false);

  // Load saved settings
  useEffect(() => {
    if (!AsyncStorage) return;
    AsyncStorage.getItem("vyweed_settings")
      .then(raw => { if (raw) setSettings({ ...DEFAULTS, ...JSON.parse(raw) }); })
      .catch(() => {});
  }, []);

  const save = async () => {
    if (AsyncStorage) {
      await AsyncStorage.setItem("vyweed_settings", JSON.stringify(settings)).catch(() => {});
    }
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const update = (key, val) => setSettings(prev => ({ ...prev, [key]: val }));

  const testConnection = async () => {
    setTesting(true);
    setApiTest(null);
    try {
      const r = await fetch(`${settings.api_url.replace("/api/v1","")}/health`,
        { signal: AbortSignal.timeout(5000) });
      setApiTest(r.ok ? "ok" : "fail");
    } catch {
      setApiTest("fail");
    } finally {
      setTesting(false);
    }
  };

  const DB_STATS_URL = `${settings.api_url}/search/stats`;

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      {/* Header */}
      <View style={{
        paddingHorizontal: 16,
        paddingTop: Platform.OS === "android" ? 16 : 52,
        paddingBottom: 14,
        borderBottomWidth: 1, borderColor: C.border,
        flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between",
      }}>
        <View>
          <Text style={{ color: C.white, fontFamily: MONO, fontSize: 22,
            fontWeight: "900", letterSpacing: 2 }}>
            VY<Text style={{ color: C.green }}>WEED</Text>
          </Text>
          <Label>SETTINGS</Label>
        </View>
        <TouchableOpacity onPress={save}
          style={{
            backgroundColor: saved ? C.greenFaint : C.surface,
            borderRadius: 6, borderWidth: 1,
            borderColor: saved ? C.green : C.border,
            paddingHorizontal: 14, paddingVertical: 8,
          }}>
          <Text style={{
            color: saved ? C.green : C.greyLight,
            fontFamily: MONO, fontSize: 12, fontWeight: "bold",
          }}>
            {saved ? "✓ SAVED" : "SAVE"}
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 50 }}>

        {/* Backend connection */}
        <Section title="BACKEND">
          <View style={{
            paddingVertical: 12, paddingHorizontal: 14,
            borderBottomWidth: 1, borderColor: C.border,
          }}>
            <Text style={{ color: C.white, fontFamily: MONO, fontSize: 13, marginBottom: 6 }}>
              API URL
            </Text>
            <TextInput
              style={{
                backgroundColor: C.surface, borderRadius: 6,
                borderWidth: 1, borderColor: C.border,
                color: C.green, fontFamily: MONO, fontSize: 13,
                padding: 10,
              }}
              value={settings.api_url}
              onChangeText={v => update("api_url", v)}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
            />
            <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10, marginTop: 4 }}>
              Termux: http://localhost:8000/api/v1{"\n"}
              LAN: http://192.168.x.x:8000/api/v1
            </Text>
          </View>

          <SettingRow
            label="TEST CONNECTION"
            sub={testing ? "Connecting..." :
              apiTest === "ok" ? "✓ Backend reachable" :
              apiTest === "fail" ? "✗ Could not connect" : "Tap to test"}
            right={
              <TouchableOpacity onPress={testConnection}
                style={{
                  backgroundColor: C.greenFaint, borderRadius: 6,
                  borderWidth: 1, borderColor: C.green,
                  paddingHorizontal: 12, paddingVertical: 7,
                }}>
                <Text style={{ color: C.green, fontFamily: MONO, fontSize: 11 }}>
                  {testing ? "..." : "TEST"}
                </Text>
              </TouchableOpacity>
            }
            last
          />
        </Section>

        {/* Grow preferences */}
        <Section title="GROW PREFERENCES">
          <SelectRow
            label="UNITS"
            options={[
              { label: "METRIC (g, °C)", value: "metric" },
              { label: "IMPERIAL (oz, °F)", value: "imperial" },
            ]}
            value={settings.units}
            onChange={v => update("units", v)}
          />
          <SelectRow
            label="DEFAULT MEDIUM"
            sub="Pre-filled when starting new grows"
            options={[
              { label: "SOIL", value: "soil" },
              { label: "COCO", value: "coco" },
              { label: "HYDRO", value: "hydro" },
            ]}
            value={settings.medium}
            onChange={v => update("medium", v)}
            last
          />
        </Section>

        {/* Database */}
        <Section title="DATABASE">
          <SettingRow
            label="STRAIN DATABASE"
            sub="5,042 strains · T1–T4 · All seedbanks"
            right={
              <View style={{
                backgroundColor: C.greenFaint, borderRadius: 6,
                borderWidth: 1, borderColor: C.greenDim,
                paddingHorizontal: 10, paddingVertical: 5,
              }}>
                <Text style={{ color: C.green, fontFamily: MONO, fontSize: 11 }}>
                  LEAFLY PARITY
                </Text>
              </View>
            }
          />
          <SettingRow
            label="VIEW LIVE STATS"
            sub={DB_STATS_URL}
            onPress={() => Linking.openURL(DB_STATS_URL).catch(() => {})}
            right={<Text style={{ color: C.grey, fontFamily: MONO, fontSize: 16 }}>→</Text>}
            last
          />
        </Section>

        {/* About */}
        <Section title="ABOUT">
          <SettingRow label="APP" right={
            <Text style={{ color: C.greyLight, fontFamily: MONO, fontSize: 12 }}>VYWEED</Text>
          } />
          <SettingRow label="VERSION" right={
            <Text style={{ color: C.greyLight, fontFamily: MONO, fontSize: 12 }}>1.0.0</Text>
          } />
          <SettingRow label="ALGORITHM" right={
            <Text style={{ color: C.greyLight, fontFamily: MONO, fontSize: 12 }}>v1 · 5,034 datasets</Text>
          } />
          <SettingRow label="PLATFORM"
            sub="Built on Samsung S22 · Termux + Expo Go"
            right={
              <Text style={{ color: C.green, fontFamily: MONO, fontSize: 14 }}>📱</Text>
            }
            last
          />
        </Section>

        {/* Legal */}
        <View style={{
          backgroundColor: C.surface, borderRadius: 8,
          borderWidth: 1, borderColor: C.border,
          padding: 12,
        }}>
          <Text style={{
            color: C.grey, fontFamily: MONO, fontSize: 10,
            lineHeight: 16, textAlign: "center",
          }}>
            VYWEED provides cultivation guidance for informational purposes only.
            Check local laws before growing cannabis. For educational use.
          </Text>
        </View>

      </ScrollView>
    </View>
  );
}
