/**
 * VYWEED Grow Tracker
 * React Native / Expo — copy to your Expo project as App.js or a screen component
 *
 * Aesthetic: Dark grow-room terminal. Deep blacks, phosphor-green accents,
 * monospace data readouts. Like a pro horticulture control panel.
 *
 * Setup:
 *   1. npm install @react-navigation/native @react-navigation/stack
 *      react-native-screens react-native-safe-area-context
 *   2. Set API_BASE to your FastAPI backend (localhost:8000 in Termux)
 *   3. Paste into App.js or wrap in your navigator
 */

import React, { useState, useEffect, useCallback } from "react";
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  Modal, ActivityIndicator, Alert, RefreshControl,
  StatusBar, Platform, Animated, Dimensions,
} from "react-native";

const { width: SW } = Dimensions.get("window");

// ── Config ────────────────────────────────────────────────────────────────────
const API_BASE = "http://localhost:8000/api/v1";

// ── Palette ───────────────────────────────────────────────────────────────────
const C = {
  bg:         "#070a07",
  surface:    "#0d120d",
  card:       "#111811",
  border:     "#1a2a1a",
  green:      "#39ff45",
  greenDim:   "#1a7a20",
  greenFaint: "#0d3d12",
  amber:      "#ffb830",
  red:        "#ff3a3a",
  blue:       "#30d5ff",
  white:      "#e8f0e8",
  grey:       "#4a5a4a",
  greyLight:  "#8a9a8a",
};

// ── Typography ────────────────────────────────────────────────────────────────
const MONO = Platform.select({ ios: "Courier New", android: "monospace" });
const SANS = Platform.select({ ios: "System", android: "sans-serif-condensed" });

// ── Tiny API client ───────────────────────────────────────────────────────────
const api = {
  async get(path) {
    const r = await fetch(`${API_BASE}${path}`);
    if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
    return r.json();
  },
  async post(path, body) {
    const r = await fetch(`${API_BASE}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
    return r.json();
  },
  async patch(path, body) {
    const r = await fetch(`${API_BASE}${path}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
    return r.json();
  },
  async del(path) {
    const r = await fetch(`${API_BASE}${path}`, { method: "DELETE" });
    if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
    return r.json();
  },
};

// ── Shared components ─────────────────────────────────────────────────────────

function GreenText({ style, children, ...props }) {
  return (
    <Text style={[{ color: C.green, fontFamily: MONO }, style]} {...props}>
      {children}
    </Text>
  );
}

function Label({ style, children }) {
  return (
    <Text style={[{ color: C.greyLight, fontFamily: MONO, fontSize: 10,
      letterSpacing: 1.5, textTransform: "uppercase" }, style]}>
      {children}
    </Text>
  );
}

function Card({ style, children }) {
  return (
    <View style={[{
      backgroundColor: C.card, borderRadius: 8,
      borderWidth: 1, borderColor: C.border,
      padding: 14, marginBottom: 12,
    }, style]}>
      {children}
    </View>
  );
}

function GreenBtn({ label, onPress, style, small, danger }) {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      style={[{
        backgroundColor: danger ? "#2a0a0a" : C.greenFaint,
        borderWidth: 1,
        borderColor: danger ? C.red : C.green,
        borderRadius: 6,
        paddingVertical: small ? 8 : 12,
        paddingHorizontal: small ? 14 : 20,
        alignItems: "center",
      }, style]}
    >
      <Text style={{
        color: danger ? C.red : C.green,
        fontFamily: MONO,
        fontSize: small ? 12 : 14,
        fontWeight: "bold",
        letterSpacing: 1,
      }}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

function StatBox({ label, value, unit, colour }) {
  return (
    <View style={{
      flex: 1, backgroundColor: C.surface, borderRadius: 6,
      borderWidth: 1, borderColor: C.border,
      padding: 10, alignItems: "center",
    }}>
      <Label>{label}</Label>
      <Text style={{
        color: colour || C.green, fontFamily: MONO,
        fontSize: 22, fontWeight: "bold", marginTop: 4,
      }}>
        {value ?? "—"}
      </Text>
      {unit && <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10 }}>{unit}</Text>}
    </View>
  );
}

function AlertBadge({ severity }) {
  const map = {
    critical: { bg: "#2a0808", border: C.red,   text: C.red,   label: "⚠ CRITICAL" },
    warning:  { bg: "#2a1a08", border: C.amber, text: C.amber, label: "▲ WARNING" },
    info:     { bg: "#081a2a", border: C.blue,  text: C.blue,  label: "ℹ INFO" },
  };
  const s = map[severity] || map.info;
  return (
    <View style={{
      backgroundColor: s.bg, borderWidth: 1, borderColor: s.border,
      borderRadius: 4, paddingHorizontal: 8, paddingVertical: 3,
      alignSelf: "flex-start",
    }}>
      <Text style={{ color: s.text, fontFamily: MONO, fontSize: 10, fontWeight: "bold" }}>
        {s.label}
      </Text>
    </View>
  );
}

function StagePill({ stage }) {
  const colour = {
    Seedling: C.blue, Vegetative: C.green,
    "Pre-Flower": C.amber, Flowering: "#ff8c30",
    Harvest: C.red,
  }[stage] || C.greyLight;
  return (
    <View style={{
      backgroundColor: `${colour}22`, borderRadius: 20,
      paddingHorizontal: 12, paddingVertical: 4,
      borderWidth: 1, borderColor: colour, alignSelf: "flex-start",
    }}>
      <Text style={{ color: colour, fontFamily: MONO, fontSize: 12, fontWeight: "bold" }}>
        {stage?.toUpperCase()}
      </Text>
    </View>
  );
}

// ── SCREEN: Grow List ─────────────────────────────────────────────────────────
function GrowListScreen({ onSelect, onNew, onCount }) {
  const [grows, setGrows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await api.get("/tracker/grows");
      setGrows(data);
      onCount?.(data.filter(g => g.status === "active").length);
    } catch (e) {
      Alert.alert("Connection Error", `Can't reach backend.\n${e.message}`);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const statusIcon = (s) => ({ active: "◉", harvested: "✓", abandoned: "✗" }[s] || "◉");
  const statusColour = (s) => ({ active: C.green, harvested: C.amber, abandoned: C.grey }[s] || C.grey);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={C.green} size="large" />
        <GreenText style={{ marginTop: 12, fontSize: 12 }}>LOADING GROWS...</GreenText>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.logo}>VY<Text style={{ color: C.green }}>WEED</Text></Text>
          <Label>GROW TRACKER</Label>
        </View>
        <GreenBtn label="+ NEW GROW" onPress={onNew} small />
      </View>

      <ScrollView
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 40 }}
        refreshControl={<RefreshControl refreshing={refreshing}
          onRefresh={() => { setRefreshing(true); load(); }} tintColor={C.green} />}
      >
        {grows.length === 0 ? (
          <View style={styles.empty}>
            <Text style={{ fontSize: 48 }}>🌱</Text>
            <GreenText style={{ fontSize: 16, marginTop: 12 }}>NO ACTIVE GROWS</GreenText>
            <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 12, marginTop: 6 }}>
              Tap + NEW GROW to start tracking
            </Text>
          </View>
        ) : (
          grows.map((g) => (
            <TouchableOpacity key={g.grow_id} onPress={() => onSelect(g)} activeOpacity={0.8}>
              <Card>
                {/* Top row */}
                <View style={styles.row}>
                  <View style={{ flex: 1 }}>
                    <GreenText style={{ fontSize: 16, fontWeight: "bold" }}>{g.strain_name}</GreenText>
                    <Text style={{ color: C.greyLight, fontFamily: MONO, fontSize: 11, marginTop: 2 }}>
                      {g.grow_id.toUpperCase()} · {g.medium.toUpperCase()}
                    </Text>
                  </View>
                  <View style={{ alignItems: "flex-end", gap: 4 }}>
                    <Text style={{ color: statusColour(g.status), fontFamily: MONO, fontSize: 12 }}>
                      {statusIcon(g.status)} {g.status.toUpperCase()}
                    </Text>
                    <StagePill stage={g.stage} />
                  </View>
                </View>

                {/* Stats row */}
                <View style={[styles.row, { marginTop: 12, gap: 8 }]}>
                  <StatBox label="DAY" value={g.current_day} />
                  <StatBox label="TO HARVEST" value={g.days_to_harvest ?? "?"} unit="days" colour={C.amber} />
                </View>

                {/* Start date */}
                <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10, marginTop: 8 }}>
                  STARTED {g.start_date}
                </Text>
              </Card>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>
    </View>
  );
}

// ── SCREEN: Grow Detail ───────────────────────────────────────────────────────
function GrowDetailScreen({ grow, onBack, onCheckin }) {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("today"); // today | alerts | harvest

  const load = useCallback(async () => {
    try {
      const data = await api.get(`/tracker/grows/${grow.grow_id}`);
      setReport(data);
    } catch (e) {
      Alert.alert("Error", e.message);
    } finally {
      setLoading(false);
    }
  }, [grow.grow_id]);

  useEffect(() => { load(); }, [load]);

  if (loading || !report) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={C.green} />
        <GreenText style={{ marginTop: 10, fontSize: 11 }}>LOADING REPORT...</GreenText>
      </View>
    );
  }

  const r = report.report || {};
  const summary = r.daily_summary || {};
  const alerts = r.environment_alerts || [];
  const harvest = r.harvest_prediction || {};
  const criticalAlerts = alerts.filter(a => a.severity === "critical");

  return (
    <View style={styles.screen}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack} style={{ padding: 4 }}>
          <GreenText style={{ fontSize: 18 }}>←</GreenText>
        </TouchableOpacity>
        <View style={{ flex: 1, marginLeft: 12 }}>
          <GreenText style={{ fontSize: 16, fontWeight: "bold" }}>{report.strain_name}</GreenText>
          <View style={[styles.row, { gap: 8, marginTop: 2 }]}>
            <StagePill stage={r.stage} />
            {criticalAlerts.length > 0 && (
              <View style={{ backgroundColor: "#2a0808", borderRadius: 4,
                paddingHorizontal: 8, paddingVertical: 3,
                borderWidth: 1, borderColor: C.red }}>
                <Text style={{ color: C.red, fontFamily: MONO, fontSize: 10, fontWeight: "bold" }}>
                  ⚠ {criticalAlerts.length} CRITICAL
                </Text>
              </View>
            )}
          </View>
        </View>
        <GreenBtn label="CHECK IN" onPress={() => onCheckin(grow)} small />
      </View>

      {/* Day counter strip */}
      <View style={{
        backgroundColor: C.greenFaint, paddingVertical: 8, paddingHorizontal: 16,
        flexDirection: "row", justifyContent: "space-between", alignItems: "center",
      }}>
        <Text style={{ color: C.green, fontFamily: MONO, fontSize: 11 }}>
          DAY {report.current_day} · {report.medium.toUpperCase()} · {report.start_date}
        </Text>
        <Text style={{ color: C.greenDim, fontFamily: MONO, fontSize: 11 }}>
          {report.env_log_count} LOGS
        </Text>
      </View>

      {/* Tab bar */}
      <View style={[styles.row, { borderBottomWidth: 1, borderColor: C.border }]}>
        {["today", "alerts", "harvest"].map(t => (
          <TouchableOpacity key={t} onPress={() => setTab(t)}
            style={{ flex: 1, paddingVertical: 12, alignItems: "center",
              borderBottomWidth: 2, borderColor: tab === t ? C.green : "transparent" }}>
            <Text style={{
              fontFamily: MONO, fontSize: 11,
              color: tab === t ? C.green : C.grey,
              letterSpacing: 1, textTransform: "uppercase",
            }}>
              {t === "today" ? "📋 Today" : t === "alerts" ? `🚨 Alerts (${alerts.length})` : "📅 Harvest"}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>

        {/* TODAY TAB */}
        {tab === "today" && (
          <>
            {summary.expert_tip_of_the_day && (
              <Card style={{ borderColor: C.greenDim, backgroundColor: C.greenFaint }}>
                <Label style={{ color: C.greenDim }}>EXPERT TIP · DAY {report.current_day}</Label>
                <Text style={{ color: C.white, fontFamily: MONO, fontSize: 13, marginTop: 6, lineHeight: 20 }}>
                  💡 {summary.expert_tip_of_the_day}
                </Text>
              </Card>
            )}

            <Card>
              <Label>TODAY'S CHECKLIST</Label>
              <View style={{ marginTop: 10, gap: 8 }}>
                {(summary.checklist || []).map((item, i) => (
                  <View key={i} style={[styles.row, { gap: 10, alignItems: "flex-start" }]}>
                    <GreenText style={{ fontSize: 14 }}>□</GreenText>
                    <Text style={{ color: C.white, fontFamily: MONO, fontSize: 13,
                      flex: 1, lineHeight: 19 }}>
                      {item}
                    </Text>
                  </View>
                ))}
              </View>
            </Card>

            {summary.watering_guidance && (
              <Card style={{ borderColor: C.blue }}>
                <Label style={{ color: C.blue }}>💧 WATERING</Label>
                <Text style={{ color: C.white, fontFamily: MONO, fontSize: 13, marginTop: 6, lineHeight: 19 }}>
                  {summary.watering_guidance}
                </Text>
              </Card>
            )}

            {summary.nutrient_guidance && (
              <Card style={{ borderColor: C.amber }}>
                <Label style={{ color: C.amber }}>🧪 NUTRIENTS</Label>
                <Text style={{ color: C.white, fontFamily: MONO, fontSize: 13, marginTop: 6, lineHeight: 19 }}>
                  {summary.nutrient_guidance}
                </Text>
              </Card>
            )}

            {summary.what_healthy_looks_like && (
              <Card>
                <Label>WHAT HEALTHY LOOKS LIKE</Label>
                <Text style={{ color: C.greyLight, fontFamily: MONO, fontSize: 12, marginTop: 6, lineHeight: 18 }}>
                  {summary.what_healthy_looks_like}
                </Text>
              </Card>
            )}

            {summary.upcoming?.length > 0 && (
              <Card>
                <Label>UPCOMING</Label>
                {summary.upcoming.map((u, i) => (
                  <Text key={i} style={{ color: C.amber, fontFamily: MONO,
                    fontSize: 12, marginTop: 6 }}>→ {u}</Text>
                ))}
              </Card>
            )}
          </>
        )}

        {/* ALERTS TAB */}
        {tab === "alerts" && (
          <>
            {alerts.length === 0 ? (
              <View style={styles.empty}>
                <GreenText style={{ fontSize: 32 }}>✓</GreenText>
                <GreenText style={{ marginTop: 8 }}>ALL CLEAR</GreenText>
                <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 12, marginTop: 4 }}>
                  No environment alerts
                </Text>
              </View>
            ) : (
              alerts.map((a, i) => (
                <Card key={i} style={{
                  borderColor: a.severity === "critical" ? C.red
                    : a.severity === "warning" ? C.amber : C.blue,
                }}>
                  <View style={[styles.row, { justifyContent: "space-between", marginBottom: 8 }]}>
                    <AlertBadge severity={a.severity} />
                    <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10 }}>
                      {a.category?.toUpperCase()}
                    </Text>
                  </View>
                  <Text style={{ color: C.white, fontFamily: MONO, fontSize: 13,
                    lineHeight: 19, marginBottom: 6 }}>
                    {a.message}
                  </Text>
                  {a.consequence && (
                    <Text style={{ color: C.amber, fontFamily: MONO, fontSize: 12,
                      lineHeight: 17, marginBottom: 6 }}>
                      ⚡ {a.consequence}
                    </Text>
                  )}
                  {a.fix && (
                    <View style={{ backgroundColor: C.greenFaint, borderRadius: 4, padding: 8 }}>
                      <Text style={{ color: C.green, fontFamily: MONO, fontSize: 12, lineHeight: 17 }}>
                        FIX: {a.fix}
                      </Text>
                    </View>
                  )}
                </Card>
              ))
            )}
          </>
        )}

        {/* HARVEST TAB */}
        {tab === "harvest" && harvest.typical_harvest && (
          <>
            <Card style={{ borderColor: C.amber }}>
              <Label style={{ color: C.amber }}>HARVEST WINDOW</Label>
              <View style={[styles.row, { gap: 8, marginTop: 12 }]}>
                <StatBox label="EARLIEST" value={harvest.earliest_harvest?.slice(5)}
                  colour={C.green} />
                <StatBox label="TYPICAL" value={harvest.typical_harvest?.slice(5)}
                  colour={C.amber} />
                <StatBox label="LATEST" value={harvest.latest_harvest?.slice(5)}
                  colour={C.red} />
              </View>
            </Card>

            <Card>
              <Label>DAYS REMAINING</Label>
              <Text style={{ color: C.amber, fontFamily: MONO,
                fontSize: 48, fontWeight: "bold", marginTop: 8 }}>
                {harvest.days_remaining_typical}
              </Text>
              <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 11 }}>days to typical harvest</Text>
            </Card>

            <Card>
              <Label>NOTE</Label>
              <Text style={{ color: C.greyLight, fontFamily: MONO,
                fontSize: 12, marginTop: 6, lineHeight: 18 }}>
                {harvest.note}
              </Text>
            </Card>

            {/* Progress bar */}
            <Card>
              <Label>GROW PROGRESS</Label>
              <View style={{ height: 8, backgroundColor: C.border, borderRadius: 4,
                marginTop: 12, overflow: "hidden" }}>
                <View style={{
                  height: 8, borderRadius: 4, backgroundColor: C.green,
                  width: `${Math.min(100, (report.current_day /
                    (report.current_day + (harvest.days_remaining_typical || 0))) * 100)}%`,
                }} />
              </View>
              <View style={[styles.row, { justifyContent: "space-between", marginTop: 4 }]}>
                <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10 }}>
                  Day {report.current_day}
                </Text>
                <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10 }}>
                  {report.current_day + (harvest.days_remaining_typical || 0)} days total
                </Text>
              </View>
            </Card>
          </>
        )}
      </ScrollView>
    </View>
  );
}

// ── MODAL: Check-in ───────────────────────────────────────────────────────────
function CheckinModal({ grow, onClose, onComplete }) {
  const [temp, setTemp] = useState("");
  const [humidity, setHumidity] = useState("");
  const [ph, setPh] = useState("");
  const [ec, setEc] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setLoading(true);
    try {
      const env = {};
      if (temp)     env.temp_day = parseFloat(temp);
      if (humidity) env.humidity = parseFloat(humidity);
      if (ph)       env.ph = parseFloat(ph);
      if (ec)       env.ec = parseFloat(ec);
      if (notes)    env.notes = notes;

      const result = await api.post(`/tracker/grows/${grow.grow_id}/checkin`, {
        env: Object.keys(env).length ? env : null,
      });

      onComplete(result);
    } catch (e) {
      Alert.alert("Error", e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={styles.modal}>
          <View style={[styles.row, { justifyContent: "space-between", marginBottom: 16 }]}>
            <GreenText style={{ fontSize: 16, fontWeight: "bold" }}>DAILY CHECK-IN</GreenText>
            <TouchableOpacity onPress={onClose}>
              <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 18 }}>✕</Text>
            </TouchableOpacity>
          </View>

          <Label style={{ marginBottom: 4 }}>STRAIN</Label>
          <Text style={{ color: C.white, fontFamily: MONO, fontSize: 14, marginBottom: 16 }}>
            {grow?.strain_name}
          </Text>

          {/* Env inputs — 2 per row */}
          <View style={[styles.row, { gap: 10, marginBottom: 10 }]}>
            <View style={{ flex: 1 }}>
              <Label>TEMP °C</Label>
              <TextInput
                style={styles.input} value={temp}
                onChangeText={setTemp} keyboardType="decimal-pad"
                placeholder="24.0" placeholderTextColor={C.grey}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Label>HUMIDITY %</Label>
              <TextInput
                style={styles.input} value={humidity}
                onChangeText={setHumidity} keyboardType="decimal-pad"
                placeholder="55" placeholderTextColor={C.grey}
              />
            </View>
          </View>

          <View style={[styles.row, { gap: 10, marginBottom: 10 }]}>
            <View style={{ flex: 1 }}>
              <Label>PH</Label>
              <TextInput
                style={styles.input} value={ph}
                onChangeText={setPh} keyboardType="decimal-pad"
                placeholder="6.3" placeholderTextColor={C.grey}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Label>EC (mS/cm)</Label>
              <TextInput
                style={styles.input} value={ec}
                onChangeText={setEc} keyboardType="decimal-pad"
                placeholder="1.4" placeholderTextColor={C.grey}
              />
            </View>
          </View>

          <Label style={{ marginBottom: 4 }}>NOTES (OPTIONAL)</Label>
          <TextInput
            style={[styles.input, { height: 64, textAlignVertical: "top" }]}
            value={notes} onChangeText={setNotes}
            placeholder="Leaves look healthy, started LST..."
            placeholderTextColor={C.grey} multiline
          />

          <GreenBtn
            label={loading ? "LOGGING..." : "LOG CHECK-IN"}
            onPress={submit} style={{ marginTop: 16 }}
          />
        </View>
      </View>
    </Modal>
  );
}

// ── MODAL: New Grow ───────────────────────────────────────────────────────────
function NewGrowModal({ onClose, onCreate }) {
  const [strainId, setStrainId] = useState("");
  const [strainName, setStrainName] = useState("");
  const [startDate, setStartDate] = useState(new Date().toISOString().slice(0, 10));
  const [medium, setMedium] = useState("soil");
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchSuggestions = async (q) => {
    if (q.length < 2) { setSuggestions([]); return; }
    try {
      const data = await api.get(`/search/suggest?q=${encodeURIComponent(q)}&limit=6`);
      setSuggestions(data.suggestions || []);
    } catch { setSuggestions([]); }
  };

  const pickSuggestion = (s) => {
    setStrainId(s.id);
    setStrainName(s.name);
    setSuggestions([]);
  };

  const submit = async () => {
    if (!strainId || !strainName) {
      Alert.alert("Required", "Select a strain first");
      return;
    }
    setLoading(true);
    try {
      const result = await api.post("/tracker/grows", {
        strain_id: strainId,
        strain_name: strainName,
        start_date: startDate,
        medium,
      });
      onCreate(result);
    } catch (e) {
      Alert.alert("Error", e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={styles.modal}>
          <View style={[styles.row, { justifyContent: "space-between", marginBottom: 16 }]}>
            <GreenText style={{ fontSize: 16, fontWeight: "bold" }}>START NEW GROW</GreenText>
            <TouchableOpacity onPress={onClose}>
              <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 18 }}>✕</Text>
            </TouchableOpacity>
          </View>

          {/* Strain search */}
          <Label style={{ marginBottom: 4 }}>SEARCH STRAIN</Label>
          <TextInput
            style={styles.input}
            value={strainName}
            onChangeText={(t) => { setStrainName(t); setStrainId(""); fetchSuggestions(t); }}
            placeholder="e.g. Gelato, OG Kush..."
            placeholderTextColor={C.grey}
          />

          {suggestions.length > 0 && (
            <View style={{
              backgroundColor: C.surface, borderRadius: 6,
              borderWidth: 1, borderColor: C.border, marginBottom: 10,
            }}>
              {suggestions.map((s) => (
                <TouchableOpacity key={s.id} onPress={() => pickSuggestion(s)}
                  style={{ padding: 12, borderBottomWidth: 1, borderColor: C.border }}>
                  <Text style={{ color: C.white, fontFamily: MONO, fontSize: 13 }}>
                    {s.name}
                  </Text>
                  <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 10 }}>
                    {s.tier} · {s.type?.toUpperCase()} · THC {s.thc_max}%
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {strainId && (
            <View style={{ backgroundColor: C.greenFaint, borderRadius: 4,
              padding: 8, marginBottom: 10, borderWidth: 1, borderColor: C.greenDim }}>
              <Text style={{ color: C.green, fontFamily: MONO, fontSize: 12 }}>
                ✓ SELECTED: {strainId}
              </Text>
            </View>
          )}

          <Label style={{ marginBottom: 4 }}>START DATE</Label>
          <TextInput
            style={[styles.input, { marginBottom: 10 }]}
            value={startDate} onChangeText={setStartDate}
            placeholder="YYYY-MM-DD" placeholderTextColor={C.grey}
          />

          <Label style={{ marginBottom: 6 }}>MEDIUM</Label>
          <View style={[styles.row, { gap: 8, marginBottom: 16 }]}>
            {["soil", "coco", "hydro"].map(m => (
              <TouchableOpacity key={m} onPress={() => setMedium(m)}
                style={{
                  flex: 1, paddingVertical: 10, borderRadius: 6, alignItems: "center",
                  borderWidth: 1,
                  borderColor: medium === m ? C.green : C.border,
                  backgroundColor: medium === m ? C.greenFaint : C.surface,
                }}>
                <Text style={{
                  color: medium === m ? C.green : C.grey,
                  fontFamily: MONO, fontSize: 12, textTransform: "uppercase",
                }}>
                  {m}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <GreenBtn
            label={loading ? "STARTING..." : "🌱 START GROW"}
            onPress={submit}
          />
        </View>
      </View>
    </Modal>
  );
}

// ── MODAL: Check-in Result ────────────────────────────────────────────────────
function CheckinResultModal({ result, onClose }) {
  if (!result) return null;
  const alerts = result.alerts || [];
  const critical = alerts.filter(a => a.severity === "critical");
  return (
    <Modal transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.modalOverlay}>
        <View style={styles.modal}>
          <GreenText style={{ fontSize: 16, fontWeight: "bold", marginBottom: 4 }}>
            ✓ CHECK-IN LOGGED
          </GreenText>
          <Text style={{ color: C.grey, fontFamily: MONO, fontSize: 11, marginBottom: 16 }}>
            DAY {result.day} · {result.stage?.toUpperCase()}
          </Text>

          {result.urgent && (
            <View style={{ backgroundColor: "#2a0808", borderRadius: 6,
              borderWidth: 1, borderColor: C.red, padding: 10, marginBottom: 12 }}>
              <Text style={{ color: C.red, fontFamily: MONO, fontSize: 13, fontWeight: "bold" }}>
                ⚠ URGENT ACTION REQUIRED
              </Text>
              {critical.map((a, i) => (
                <Text key={i} style={{ color: C.red, fontFamily: MONO,
                  fontSize: 12, marginTop: 4 }}>
                  · {a.message}
                </Text>
              ))}
            </View>
          )}

          {result.tip && (
            <Card style={{ borderColor: C.greenDim }}>
              <Text style={{ color: C.white, fontFamily: MONO, fontSize: 12, lineHeight: 18 }}>
                💡 {result.tip}
              </Text>
            </Card>
          )}

          <Text style={{ color: C.greyLight, fontFamily: MONO,
            fontSize: 11, marginBottom: 12 }}>
            CHECKLIST ({result.checklist?.length || 0} items)
          </Text>
          {(result.checklist || []).slice(0, 4).map((item, i) => (
            <Text key={i} style={{ color: C.white, fontFamily: MONO,
              fontSize: 12, marginBottom: 4 }}>
              □ {item}
            </Text>
          ))}

          <GreenBtn label="DONE" onPress={onClose} style={{ marginTop: 16 }} />
        </View>
      </View>
    </Modal>
  );
}

// ── Root App ──────────────────────────────────────────────────────────────────
export default function VYWEEDGrowTracker({ onGrowCountChange }) {
  const [screen, setScreen] = useState("list");       // list | detail
  const [selectedGrow, setSelectedGrow] = useState(null);
  const [showNewGrow, setShowNewGrow] = useState(false);
  const [showCheckin, setShowCheckin] = useState(false);
  const [checkinTarget, setCheckinTarget] = useState(null);
  const [checkinResult, setCheckinResult] = useState(null);
  const [listKey, setListKey] = useState(0); // force re-render list

  const handleSelectGrow = (grow) => {
    setSelectedGrow(grow);
    setScreen("detail");
  };

  const handleCheckinComplete = (result) => {
    setShowCheckin(false);
    setCheckinResult(result);
  };

  // Notify parent of active grow count for tab badge
  React.useEffect(() => {
    if (onGrowCountChange) onGrowCountChange(0); // updated after list loads
  }, [listKey]);

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />

      {screen === "list" && (
        <GrowListScreen
          key={listKey}
          onSelect={handleSelectGrow}
          onNew={() => setShowNewGrow(true)}
          onCount={(n) => onGrowCountChange?.(n)}
        />
      )}

      {screen === "detail" && selectedGrow && (
        <GrowDetailScreen
          grow={selectedGrow}
          onBack={() => setScreen("list")}
          onCheckin={(g) => { setCheckinTarget(g); setShowCheckin(true); }}
        />
      )}

      {showNewGrow && (
        <NewGrowModal
          onClose={() => setShowNewGrow(false)}
          onCreate={(result) => {
            setShowNewGrow(false);
            setListKey(k => k + 1);
            Alert.alert("🌱 Grow Started", `Grow ID: ${result.grow_id}`);
          }}
        />
      )}

      {showCheckin && checkinTarget && (
        <CheckinModal
          grow={checkinTarget}
          onClose={() => setShowCheckin(false)}
          onComplete={handleCheckinComplete}
        />
      )}

      {checkinResult && (
        <CheckinResultModal
          result={checkinResult}
          onClose={() => setCheckinResult(null)}
        />
      )}
    </View>
  );
}

// ── Shared styles ─────────────────────────────────────────────────────────────
const styles = {
  screen:  { flex: 1, backgroundColor: C.bg },
  center:  { flex: 1, backgroundColor: C.bg, alignItems: "center", justifyContent: "center" },
  row:     { flexDirection: "row", alignItems: "center" },
  empty:   { alignItems: "center", justifyContent: "center", paddingVertical: 60 },

  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingTop: Platform.OS === "android" ? 16 : 52,
    paddingBottom: 12,
    borderBottomWidth: 1, borderColor: C.border,
  },

  logo: {
    color: C.white, fontSize: 22, fontWeight: "900",
    fontFamily: Platform.select({ ios: "Courier New", android: "monospace" }),
    letterSpacing: 2,
  },

  modalOverlay: {
    flex: 1, backgroundColor: "rgba(0,0,0,0.85)",
    justifyContent: "flex-end",
  },

  modal: {
    backgroundColor: C.card, borderTopLeftRadius: 20, borderTopRightRadius: 20,
    borderTopWidth: 1, borderColor: C.border,
    padding: 20, paddingBottom: 40,
    maxHeight: "92%",
  },

  input: {
    backgroundColor: C.surface, borderRadius: 6,
    borderWidth: 1, borderColor: C.border,
    color: C.white, fontFamily: MONO,
    fontSize: 14, padding: 12, marginBottom: 10,
  },
};
